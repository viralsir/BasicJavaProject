package access_idenfiter_demo;

public class optionfour extends optionone
{
    public static void main(String[] args)
    {
        //optionone ob=new optionone();
        optionfour ob=new optionfour();
       // System.out.println("private int pr :"+ob.pr);
        System.out.println("protected int pro :"+ob.pro);
        System.out.println("defualt int d :"+ob.d);
        System.out.println("public int pu :"+ob.pu);
    }
}
