package access_identifier_demo2;
import access_idenfiter_demo.optionone;
public class optionfive //extends optionone
{

    public static void main(String[] args)
    {
        optionone ob=new optionone();
       // optionfive ob = new optionfive();
       // System.out.println("private int pr :"+ob.pr);
       // System.out.println("protected int pro :"+ob.pro);
       // System.out.println("defualt int d :"+ob.d);
        System.out.println("public int pu :"+ob.pu);
    }
}
